
const width = 1200;
const height = 650;

const tooltip = d3.select("#tooltip");

// Department color palette
const colors = [
    "#2563eb",
    "#059669",
    "#ea580c",
    "#9333ea"
];

// Load university.csv
d3.csv("university.csv", function (d) {
    return {
        department: d.department.trim(),
        course: d.course.trim(),
        students: +d.students
    };
}).then(function (data) {

    // Validate CSV data
    data = data.filter(d =>
        d.department &&
        d.course &&
        Number.isFinite(d.students) &&
        d.students >= 0
    );

    if (data.length === 0) {
        throw new Error(
            "No valid rows found. Check your CSV column names and data."
        );
    }

    // Calculate summary statistics
    const totalStudents = d3.sum(data, d => d.students);
    const departments = Array.from(
        new Set(data.map(d => d.department))
    );

    const totalCourses = data.length;

    d3.select("#totalStudents")
        .text(totalStudents.toLocaleString());

    d3.select("#totalDepartments")
        .text(departments.length);

    d3.select("#totalCourses")
        .text(totalCourses);

    // Create a color scale for departments
    const color = d3.scaleOrdinal()
        .domain(departments)
        .range(colors.concat(d3.schemeTableau10));

    // Build hierarchy:
    // University -> Department -> Course
    const hierarchyData = {
        name: "University",
        children: Array.from(
            d3.group(data, d => d.department),
            ([department, courses]) => ({
                name: department,
                children: courses.map(d => ({
                    name: d.course,
                    students: d.students,
                    value: d.students
                }))
            })
        )
    };

    // Convert data into a D3 hierarchy
    const root = d3.hierarchy(hierarchyData)
        .sum(d => d.value || 0)
        .sort((a, b) => b.value - a.value);

    // Create treemap layout
    d3.treemap()
        .size([width, height])
        .tile(d3.treemapSquarify)
        .paddingOuter(5)
        .paddingTop(28)
        .paddingInner(3)
        .round(true)(root);

    // Create SVG
    const svg = d3.select("#chart")
        .append("svg")
        .attr("viewBox", `0 0 ${width} ${height}`)
        .attr("preserveAspectRatio", "xMidYMid meet")
        .attr("role", "img")
        .attr(
            "aria-label",
            "Treemap showing university enrollment by department and course"
        );

    // Department groups
    const departmentGroups = svg.selectAll(".department")
        .data(root.children)
        .join("g")
        .attr("class", "department");

    // Department background
    departmentGroups.append("rect")
        .attr("x", d => d.x0)
        .attr("y", d => d.y0)
        .attr("width", d => Math.max(0, d.x1 - d.x0))
        .attr("height", d => Math.max(0, d.y1 - d.y0))
        .attr("fill", d => color(d.data.name))
        .attr("fill-opacity", 0.12);

    // Department border
    departmentGroups.append("rect")
        .attr("class", "department-border")
        .attr("x", d => d.x0)
        .attr("y", d => d.y0)
        .attr("width", d => Math.max(0, d.x1 - d.x0))
        .attr("height", d => Math.max(0, d.y1 - d.y0))
        .attr("stroke", d => color(d.data.name));

    // Department name labels
    departmentGroups.append("text")
        .attr("class", "department-label")
        .attr("x", d => d.x0 + 8)
        .attr("y", d => d.y0 + 19)
        .attr("fill", d => color(d.data.name))
        .text(d => d.data.name)
        .each(function (d) {
            const availableWidth = d.x1 - d.x0 - 16;

            if (availableWidth < 50) {
                d3.select(this).remove();
                return;
            }

            const maxChars = Math.floor(availableWidth / 7);

            if (d.data.name.length > maxChars) {
                d3.select(this).text(
                    d.data.name.slice(0, Math.max(1, maxChars - 1)) + "…"
                );
            }
        });

    // Get every course leaf
    const leaves = root.leaves();

    // Course rectangle groups
    const courseGroups = svg.selectAll(".course")
        .data(leaves)
        .join("g")
        .attr("class", "course");

    // Draw course rectangles
    courseGroups.append("rect")
        .attr("class", "tile")
        .attr("x", d => d.x0)
        .attr("y", d => d.y0)
        .attr("width", d => Math.max(0, d.x1 - d.x0))
        .attr("height", d => Math.max(0, d.y1 - d.y0))
        .attr("fill", d => color(d.parent.data.name))
        .on("mouseenter", function (event, d) {
            tooltip
                .style("display", "block")
                .html(`
                    <strong>Course:</strong> ${escapeHTML(d.data.name)}<br>
                    <strong>Department:</strong> ${escapeHTML(d.parent.data.name)}<br>
                    <strong>Students:</strong> ${d.value.toLocaleString()}
                `);
        })
        .on("mousemove", function (event) {
            const tooltipNode = tooltip.node();
            const tooltipWidth = tooltipNode.offsetWidth;
            const tooltipHeight = tooltipNode.offsetHeight;

            let left = event.pageX + 15;
            let top = event.pageY + 15;

            if (left + tooltipWidth > window.scrollX + window.innerWidth) {
                left = event.pageX - tooltipWidth - 15;
            }

            if (top + tooltipHeight > window.scrollY + window.innerHeight) {
                top = event.pageY - tooltipHeight - 15;
            }

            tooltip
                .style("left", left + "px")
                .style("top", top + "px");
        })
        .on("mouseleave", function () {
            tooltip.style("display", "none");
        });

    // Add course labels
    courseGroups.append("text")
        .attr("class", "course-label")
        .attr("x", d => d.x0 + 6)
        .attr("y", d => d.y0 + 18)
        .each(function (d) {
            const rectWidth = d.x1 - d.x0;
            const rectHeight = d.y1 - d.y0;

            // Do not show labels in very small rectangles
            if (rectWidth < 55 || rectHeight < 32) {
                d3.select(this).remove();
                return;
            }

            const maxChars = Math.floor((rectWidth - 12) / 7);
            let label = d.data.name;

            if (label.length > maxChars) {
                label = label.slice(0, Math.max(1, maxChars - 1)) + "…";
            }

            d3.select(this)
                .text(label)
                .append("title")
                .text(d.data.name);
        });

    // Create the department legend
    const legend = d3.select("#legend");

    legend.selectAll(".legend-item")
        .data(departments)
        .join("div")
        .attr("class", "legend-item")
        .each(function (department) {
            const item = d3.select(this);

            item.append("span")
                .attr("class", "legend-color")
                .style("background-color", color(department));

            item.append("span")
                .text(department);
        });

}).catch(function (error) {
    console.error("Error loading university.csv:", error);

    d3.select("#chart")
        .append("p")
        .style("color", "red")
        .style("text-align", "center")
        .text(
            "Unable to load the dataset. Make sure university.csv is in the same folder and contains department, course, and students columns."
        );
});

// Escape text before inserting CSV values into tooltip HTML
function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}
