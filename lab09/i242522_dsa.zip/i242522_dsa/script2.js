
const width = 1200;

const margin = {
    top: 40,
    right: 240,
    bottom: 40,
    left: 240
};

// Colors based on hierarchy depth
const nodeColors = {
    0: "#7c3aed", // University
    1: "#0284c7", // Department
    2: "#059669"  // Course
};

// Load the dataset
d3.csv("university.csv").then(function (data) {

    // Validate CSV columns
    const required = ["department", "course", "students"];

    if (!required.every(col => data.columns.includes(col))) {
        throw new Error(
            "CSV must contain department, course, and students columns."
        );
    }

    // Clean the data
    data = data.map(d => ({
        department: (d.department || "").trim(),
        course: (d.course || "").trim(),
        students: Number(d.students)
    })).filter(d =>
        d.department &&
        d.course &&
        Number.isFinite(d.students)
    );

    if (data.length === 0) {
        throw new Error("No valid data found in university.csv.");
    }

    // Build the hierarchy
    const hierarchyData = {
        name: "University",
        children: Array.from(
            d3.group(data, d => d.department),
            ([department, courses]) => ({
                name: department,
                children: courses.map(d => ({
                    name: d.course,
                    students: d.students
                }))
            })
        )
    };

    const root = d3.hierarchy(hierarchyData);

    // Save department children for collapse/expand
    root.each(d => {
        if (d.depth === 1) {
            d._children = d.children;
        }
    });

    // Create the SVG
    const svg = d3.select("#chart")
        .append("svg")
        .attr("viewBox", "0 0 1200 700")
        .attr("width", "100%")
        .attr("role", "img")
        .attr("aria-label", "University structure dendrogram");

    const chart = svg.append("g");

    // Horizontal tree layout
    const tree = d3.tree()
        .nodeSize([42, 220]);

    function update() {
        tree(root);

        const nodes = root.descendants();
        const links = root.links();

        // Calculate the required height
        const minX = d3.min(nodes, d => d.x);
        const maxX = d3.max(nodes, d => d.x);

        const height = Math.max(650, maxX - minX + 100);

        svg.attr("viewBox", `0 0 ${width} ${height}`);

        chart.attr(
            "transform",
            `translate(${margin.left},${40 - minX})`
        );

        // Draw curved links
        const link = chart.selectAll(".link")
            .data(links, d =>
                d.target.ancestors()
                    .map(a => a.data.name)
                    .reverse()
                    .join("/")
            );

        link.exit().remove();

        link.enter()
            .append("path")
            .attr("class", "link")
            .merge(link)
            .attr("d", d3.linkHorizontal()
                .x(d => d.y)
                .y(d => d.x)
            );

        // Draw nodes
        const node = chart.selectAll(".node")
            .data(nodes, d =>
                d.ancestors()
                    .map(a => a.data.name)
                    .reverse()
                    .join("/")
            );

        node.exit().remove();

        const nodeEnter = node.enter()
            .append("g")
            .attr("class", "node")
            .attr("transform", d => `translate(${d.y},${d.x})`);

        // Circles
        nodeEnter.append("circle")
            .attr("r", d => d.depth === 0 ? 10 : 7)
            .attr("fill", d => nodeColors[d.depth]);

        // Labels
        nodeEnter.append("text")
            .attr("dy", "0.35em");

        const allNodes = nodeEnter.merge(node);

        allNodes
            .attr("class", d =>
                "node " +
                (d.depth === 0 ? "root" :
                    d.depth === 1 ? "department" : "course")
            )
            .attr("transform", d => `translate(${d.y},${d.x})`);

        allNodes.select("circle")
            .attr("fill", d => nodeColors[d.depth])
            .attr("r", d => d.depth === 0 ? 10 : 7);

        allNodes.select("text")
            .attr("x", d => d.depth === 2 ? 13 : -13)
            .attr("text-anchor", d =>
                d.depth === 2 ? "start" : "end"
            )
            .text(d =>
                d._children ? d.data.name + " (+)" : d.data.name
            );

        // Click departments to collapse or expand courses
        allNodes
            .style("cursor", d =>
                d.depth === 1 ? "pointer" : "default"
            )
            .on("click", function (event, d) {
                if (d.depth !== 1) return;

                if (d.children) {
                    d._children = d.children;
                    d.children = null;
                } else {
                    d.children = d._children;
                    d._children = null;
                }

                update();
            });
    }

    update();

}).catch(function (error) {
    console.error("Dendrogram error:", error);

    d3.select("#error")
        .text("Unable to display dendrogram: " + error.message);
});
