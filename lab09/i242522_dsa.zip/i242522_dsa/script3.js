
const svg = d3.select("#network");

const width = Math.min(window.innerWidth - 30, 1200);
const height = 650;

svg
    .attr("width", width)
    .attr("height", height)
    .attr("viewBox", `0 0 ${width} ${height}`);

const errorDiv = d3.select("#error");

// Read the CSV file
d3.csv("flights.csv", d => ({
    source: d.source.trim(),
    target: d.target.trim(),
    flights: +d.flights
}))
.then(data => {
    if (!data.length) {
        throw new Error("The CSV file contains no flight routes.");
    }

    if (data.some(d =>
        !d.source ||
        !d.target ||
        !Number.isFinite(d.flights) ||
        d.flights < 0
    )) {
        throw new Error(
            "Check flights.csv: source, target, and non-negative flights are required."
        );
    }

    // 1. Build the node list from the edge list
    const cityNames = [
        ...new Set(data.flatMap(d => [d.source, d.target]))
    ];

    const nodes = cityNames.map(name => ({
        id: name,
        degree: 0
    }));

    // Calculate degree: number of routes connected to each city
    data.forEach(link => {
        const source = nodes.find(n => n.id === link.source);
        const target = nodes.find(n => n.id === link.target);

        if (source) source.degree++;
        if (target) target.degree++;
    });

    // 2. Scales
    const linkWidth = d3.scaleLinear()
        .domain(d3.extent(data, d => d.flights))
        .range([1, 7])
        .clamp(true);

    const nodeRadius = d3.scaleSqrt()
        .domain([0, d3.max(nodes, d => d.degree) || 1])
        .range([7, 25]);

    const nodeColor = d3.scaleOrdinal()
        .domain(cityNames)
        .range(d3.schemeTableau10);

    // 3. Create SVG groups
    const linkGroup = svg.append("g")
        .attr("class", "links");

    const labelGroup = svg.append("g")
        .attr("class", "link-labels");

    const nodeGroup = svg.append("g")
        .attr("class", "nodes");

    // 4. Draw links
    const links = linkGroup
        .selectAll("line")
        .data(data)
        .join("line")
        .attr("class", "link")
        .attr("stroke-width", d => linkWidth(d.flights));

    // Show the number of weekly flights on each link
    const linkLabels = labelGroup
        .selectAll("text")
        .data(data)
        .join("text")
        .attr("class", "link-label")
        .attr("text-anchor", "middle")
        .text(d => d.flights);

    // 5. Draw nodes and city labels
    const node = nodeGroup
        .selectAll("g")
        .data(nodes)
        .join("g")
        .attr("class", "node");

    node.append("circle")
        .attr("r", d => nodeRadius(d.degree))
        .attr("fill", d => nodeColor(d.id));

    node.append("text")
        .attr("dy", d => nodeRadius(d.degree) + 15)
        .text(d => d.id);

    // Show city information on hover
    node.append("title")
        .text(d => `${d.id}\nRoutes (degree): ${d.degree}`);

    // 6. Force-directed simulation
    const simulation = d3.forceSimulation(nodes)
        .force("link", d3.forceLink(data)
            .id(d => d.id)
            .distance(130)
            .strength(0.5))
        .force("charge", d3.forceManyBody().strength(-400))
        .force("center", d3.forceCenter(width / 2, height / 2))
        .force("collide", d3.forceCollide()
            .radius(d => nodeRadius(d.degree) + 12))
        .force("x", d3.forceX(width / 2).strength(0.04))
        .force("y", d3.forceY(height / 2).strength(0.04));

    // 7. Update positions on every simulation tick
    simulation.on("tick", () => {
        links
            .attr("x1", d => d.source.x)
            .attr("y1", d => d.source.y)
            .attr("x2", d => d.target.x)
            .attr("y2", d => d.target.y);

        linkLabels
            .attr("x", d => (d.source.x + d.target.x) / 2)
            .attr("y", d => (d.source.y + d.target.y) / 2 - 5);

        node.attr("transform",
            d => `translate(${d.x},${d.y})`);
    });

    // 8. Drag behavior
    node.call(
        d3.drag()
            .on("start", (event, d) => {
                if (!event.active) {
                    simulation.alphaTarget(0.3).restart();
                }

                d.fx = d.x;
                d.fy = d.y;
            })
            .on("drag", (event, d) => {
                d.fx = event.x;
                d.fy = event.y;
            })
            .on("end", (event, d) => {
                if (!event.active) {
                    simulation.alphaTarget(0);
                }

                // Release node so the simulation can reposition it
                d.fx = null;
                d.fy = null;
            })
    );

    // 9. Hover highlighting
    node
        .on("mouseenter", function(event, city) {
            // Fade all links except routes connected to this city
            links
                .transition()
                .duration(150)
                .attr("stroke-opacity", d =>
                    d.source.id === city.id ||
                    d.target.id === city.id ? 1 : 0.06
                )
                .attr("stroke", d =>
                    d.source.id === city.id ||
                    d.target.id === city.id ? "#f97316" : "#94a3b8"
                );

            // Fade labels for unrelated routes
            linkLabels
                .transition()
                .duration(150)
                .attr("opacity", d =>
                    d.source.id === city.id ||
                    d.target.id === city.id ? 1 : 0.05
                );

            // Fade unrelated cities
            node
                .transition()
                .duration(150)
                .attr("opacity", d => {
                    const connected = data.some(link =>
                        (link.source.id === city.id &&
                         link.target.id === d.id) ||
                        (link.target.id === city.id &&
                         link.source.id === d.id)
                    );

                    return d.id === city.id || connected ? 1 : 0.2;
                });

            // Enlarge the hovered city slightly
            d3.select(this)
                .select("circle")
                .transition()
                .duration(150)
                .attr("stroke", "#f97316")
                .attr("stroke-width", 4);
        })
        .on("mouseleave", function() {
            // Restore all links and labels
            links
                .transition()
                .duration(150)
                .attr("stroke-opacity", 0.7)
                .attr("stroke", "#94a3b8");

            linkLabels
                .transition()
                .duration(150)
                .attr("opacity", 1);

            node
                .transition()
                .duration(150)
                .attr("opacity", 1);

            d3.select(this)
                .select("circle")
                .transition()
                .duration(150)
                .attr("stroke", "white")
                .attr("stroke-width", 2);
        });

    errorDiv.text("");

})
.catch(error => {
    console.error("Error loading flight data:", error);

    errorDiv.text(
        "Unable to load flights.csv. Check the file name, CSV format, and local server."
    );
});
