
const svg = d3.select("#world-map");
const tooltip = d3.select("#tooltip");
const errorDiv = d3.select("#error");

const width = 1100;
const height = 580;

const noDataColor = "#d9d9d9";

// World GeoJSON loaded directly from a URL
const worldUrl =
    "https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson";

// Normalize country codes so values like "586" and "0586" match.
function normalizeCode(value) {
    if (value === null || value === undefined) {
        return "";
    }

    const code = String(value).trim().toUpperCase();

    // Normalize numeric codes only.
    if (/^\d+$/.test(code)) {
        return String(Number(code));
    }

    return code;
}

// Load the CSV and world GeoJSON together.
Promise.all([
    d3.csv("population.csv", d => ({
        id: normalizeCode(d.id),
        country: (d.country || "").trim(),
        population: Number(d.population_millions)
    })),

    d3.json(worldUrl)
])
.then(([populationData, world]) => {

    // Check the loaded data.
    if (!world || !Array.isArray(world.features)) {
        throw new Error(
            "The URL did not return a valid GeoJSON FeatureCollection."
        );
    }

    if (populationData.length === 0) {
        throw new Error("population.csv is empty.");
    }

    // --------------------------------------------------
    // 1. Identify the country-code property in GeoJSON
    // --------------------------------------------------

    const possibleCodeProperties = [
        "ISO_A3",
        "iso_a3",
        "ISO3166-1-Alpha-3",
        "ISO_N3",
        "iso_n3",
        "ISO3166-1-numeric",
        "ADM0_A3",
        "SOV_A3",
        "id"
    ];

    const firstFeature = world.features.find(
        feature => feature.properties
    );

    if (!firstFeature) {
        throw new Error("The GeoJSON has no country features.");
    }

    // Find a property that exists in the GeoJSON.
    const codeProperty = possibleCodeProperties.find(key =>
        world.features.some(feature => {
            const value = key === "id"
                ? feature.id ?? feature.properties?.id
                : feature.properties?.[key];

            return value !== null &&
                   value !== undefined &&
                   String(value).trim() !== "";
        })
    );

    if (!codeProperty) {
        throw new Error(
            "No recognized country-code property was found in the GeoJSON."
        );
    }

    console.log("GeoJSON country-code property:", codeProperty);

    function getCountryCode(feature) {
        const value = codeProperty === "id"
            ? feature.id ?? feature.properties?.id
            : feature.properties?.[codeProperty];

        return normalizeCode(value);
    }

    // --------------------------------------------------
    // 2. Build a lookup table from population.csv
    // --------------------------------------------------

    const validPopulationData = populationData.filter(d =>
        d.id !== "" &&
        Number.isFinite(d.population) &&
        d.population >= 0
    );

    if (validPopulationData.length === 0) {
        throw new Error(
            "No valid population records. Check the id and population_millions columns."
        );
    }

    const populationByCode = new Map(
        validPopulationData.map(d => [d.id, d])
    );

    // Join the population data to the geographical features.
    world.features.forEach(feature => {
        const code = getCountryCode(feature);

        feature.populationRecord =
            populationByCode.get(code) || null;
    });

    const matchedCount = world.features.filter(
        feature => feature.populationRecord !== null
    ).length;

    console.log(
        `Matched ${matchedCount} of ${world.features.length} map features.`
    );

    if (matchedCount === 0) {
        throw new Error(
            "No country codes matched. Check whether population.csv uses numeric IDs or ISO alpha-3 codes, and verify the GeoJSON code property."
        );
    }

    // --------------------------------------------------
    // 3. Create a map projection and path generator
    // --------------------------------------------------

    const projection = d3.geoNaturalEarth1()
        .fitSize([width, height], world);

    const path = d3.geoPath()
        .projection(projection);

    // --------------------------------------------------
    // 4. Create a sequential square-root color scale
    // --------------------------------------------------

    const populationValues = validPopulationData.map(
        d => d.population
    );

    const minPopulation = d3.min(populationValues);
    const maxPopulation = d3.max(populationValues);

    // Square-root transformation makes large values less dominant.
    // Handle the special case where every population is identical.
    const minRoot = Math.sqrt(minPopulation);
    const maxRoot = Math.sqrt(maxPopulation);

    const color = d3.scaleSequential()
        .domain(
            minRoot === maxRoot
                ? [minRoot, minRoot + 1]
                : [minRoot, maxRoot]
        )
        .interpolator(d3.interpolateYlOrRd)
        .clamp(true);

    function getCountryColor(feature) {
        const record = feature.populationRecord;

        if (!record) {
            return noDataColor;
        }

        return color(Math.sqrt(record.population));
    }

    // --------------------------------------------------
    // 5. Draw country shapes
    // --------------------------------------------------

    const countries = svg.append("g")
        .attr("class", "countries")
        .selectAll("path")
        .data(world.features)
        .join("path")
        .attr("class", "country")
        .attr("d", path)
        .attr("fill", getCountryColor);

    // Extract country names from common GeoJSON properties.
    function getCountryName(feature) {
        const properties = feature.properties || {};

        if (feature.populationRecord?.country) {
            return feature.populationRecord.country;
        }

        return properties.ADMIN ||
               properties.name ||
               properties.NAME ||
               properties.name_en ||
               properties.name_long ||
               "Unknown country";
    }

    function formatPopulation(value) {
        return value.toLocaleString(undefined, {
            maximumFractionDigits: 2
        }) + " million";
    }

    // --------------------------------------------------
    // 6. Add tooltip and highlight country border
    // --------------------------------------------------

    countries
        .on("mouseenter", function(event, feature) {

            d3.select(this)
                .raise()
                .attr("stroke", "#111827")
                .attr("stroke-width", 1.5);

            const record = feature.populationRecord;

            const populationText = record
                ? formatPopulation(record.population)
                : "No data available";

            tooltip
                .style("display", "block")
                .html(`
                    <strong>${getCountryName(feature)}</strong><br>
                    Population: ${populationText}
                `);
        })

        .on("mousemove", function(event) {

            const tooltipWidth = 230;
            const tooltipHeight = 70;

            const left = Math.min(
                event.clientX + 15,
                window.innerWidth - tooltipWidth - 10
            );

            const top = Math.min(
                event.clientY + 15,
                window.innerHeight - tooltipHeight - 10
            );

            tooltip
                .style("left", Math.max(5, left) + "px")
                .style("top", Math.max(5, top) + "px");
        })

        .on("mouseleave", function() {

            d3.select(this)
                .attr("stroke", "#ffffff")
                .attr("stroke-width", 0.5);

            tooltip.style("display", "none");
        });

    // --------------------------------------------------
    // 7. Create a color legend
    // --------------------------------------------------

    const legendWidth = 650;

    const legendSvg = d3.select("#legend")
        .append("svg")
        .attr("viewBox", `0 0 ${legendWidth} 85`)
        .attr("role", "img")
        .attr("aria-label", "Population color legend");

    const defs = legendSvg.append("defs");

    const gradientId = "population-gradient";

    const gradient = defs.append("linearGradient")
        .attr("id", gradientId)
        .attr("x1", "0%")
        .attr("x2", "100%")
        .attr("y1", "0%")
        .attr("y2", "0%");

    // Add gradient stops using the same color scale as the map.
    d3.range(0, 101).forEach(i => {

        const t = i / 100;

        const transformedValue =
            minRoot + t * (maxRoot - minRoot);

        gradient.append("stop")
            .attr("offset", `${i}%`)
            .attr("stop-color", color(transformedValue));
    });

    legendSvg.append("text")
        .attr("x", 0)
        .attr("y", 10)
        .attr("font-size", 13)
        .attr("font-weight", "bold")
        .text("Population (millions)");

    legendSvg.append("rect")
        .attr("x", 0)
        .attr("y", 18)
        .attr("width", legendWidth)
        .attr("height", 16)
        .attr("rx", 3)
        .attr("fill", `url(#${gradientId})`);

    legendSvg.append("text")
        .attr("x", 0)
        .attr("y", 51)
        .attr("text-anchor", "start")
        .attr("font-size", 12)
        .text(`Minimum: ${minPopulation} million`);

    legendSvg.append("text")
        .attr("x", legendWidth)
        .attr("y", 51)
        .attr("text-anchor", "end")
        .attr("font-size", 12)
        .text(`Maximum: ${maxPopulation} million`);

    // Missing-data legend key
    legendSvg.append("rect")
        .attr("x", 0)
        .attr("y", 63)
        .attr("width", 13)
        .attr("height", 13)
        .attr("fill", noDataColor)
        .attr("stroke", "#999");

    legendSvg.append("text")
        .attr("x", 20)
        .attr("y", 74)
        .attr("font-size", 11)
        .text("No population data");

    errorDiv.text("");

})
.catch(error => {

    console.error("World map error:", error);

    errorDiv.text(
        "Error: " + error.message
    );
});
