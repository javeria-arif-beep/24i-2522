
const svg = d3.select("#map");
const tooltip = d3.select("#tooltip");
const errorDiv = d3.select("#error");

const width = 1000;
const height = 700;

// Direct URL for world country boundaries
const worldUrl =
    "https://raw.githubusercontent.com/datasets/geo-countries/master/data/countries.geojson";

// Format population for display
function formatPopulation(value) {
    return Number(value).toLocaleString();
}

// Load both datasets
Promise.all([
    d3.csv("pakistan_cities.csv", d => ({
        name: d.name.trim(),
        lat: Number(d.lat),
        lon: Number(d.lon),
        pop: Number(d.pop)
    })),

    d3.json(worldUrl)
])
.then(([cities, world]) => {

    // Validate the CSV data
    cities = cities.filter(d =>
        d.name &&
        Number.isFinite(d.lat) &&
        Number.isFinite(d.lon) &&
        Number.isFinite(d.pop) &&
        d.lat >= -90 &&
        d.lat <= 90 &&
        d.lon >= -180 &&
        d.lon <= 180 &&
        d.pop >= 0
    );

    if (cities.length === 0) {
        throw new Error(
            "No valid cities found. Check name, lat, lon, and pop in the CSV."
        );
    }

    if (!world || !Array.isArray(world.features)) {
        throw new Error("The world GeoJSON file is invalid.");
    }

    // ------------------------------------------------
    // 1. Find Pakistan in the GeoJSON
    // ------------------------------------------------

    const pakistan = world.features.find(feature => {
        const p = feature.properties || {};

        const code = String(
            p.ISO_A3 ??
            p.iso_a3 ??
            p["ISO3166-1-Alpha-3"] ??
            ""
        ).trim().toUpperCase();

        const name = String(
            p.ADMIN ?? p.name ?? p.NAME ?? ""
        ).trim().toLowerCase();

        return code === "PAK" || name === "pakistan";
    });

    if (!pakistan) {
        throw new Error(
            "Pakistan was not found in the GeoJSON country features."
        );
    }

    // ------------------------------------------------
    // 2. Mercator projection centered and zoomed on Pakistan
    // ------------------------------------------------

    const projection = d3.geoMercator()
        .fitExtent(
            [[35, 35], [width - 35, height - 35]],
            pakistan
        );

    // Convert geographical coordinates into SVG paths
    const path = d3.geoPath()
        .projection(projection);

    // ------------------------------------------------
    // 3. Draw world countries as a background
    // ------------------------------------------------

    svg.append("g")
        .attr("class", "countries")
        .selectAll("path")
        .data(world.features)
        .join("path")
        .attr("class", feature =>
            feature === pakistan
                ? "country pakistan"
                : "country"
        )
        .attr("d", path);

    // ------------------------------------------------
    // 4. Create square-root radius scale
    // ------------------------------------------------

    const maxPopulation = d3.max(cities, d => d.pop) || 1;

    const radiusScale = d3.scaleSqrt()
        .domain([0, maxPopulation])
        .range([3, 25]);

    // ------------------------------------------------
    // 5. Convert longitude and latitude into map points
    // ------------------------------------------------

    cities.forEach(city => {
        // IMPORTANT: longitude first, latitude second
        city.coordinates = projection([city.lon, city.lat]);
    });

    // ------------------------------------------------
    // 6. Draw city circles
    // ------------------------------------------------

    const cityGroups = svg.append("g")
        .attr("class", "cities")
        .selectAll("g")
        .data(cities)
        .join("g")
        .attr("class", "city")
        .attr(
            "transform",
            d => `translate(${d.coordinates[0]},${d.coordinates[1]})`
        );

    cityGroups.append("circle")
        .attr("class", "city-circle")
        .attr("r", d => radiusScale(d.pop));

    // ------------------------------------------------
    // 7. Label only cities with population > 1 million
    // ------------------------------------------------

    cityGroups
        .filter(d => d.pop > 1000000)
        .append("text")
        .attr("class", "city-label")
        .attr("x", 7)
        .attr("y", -7)
        .text(d => d.name);

    // ------------------------------------------------
    // 8. Tooltip for every city
    // ------------------------------------------------

    cityGroups
        .on("mouseenter", function(event, city) {

            d3.select(this)
                .raise();

            tooltip
                .style("display", "block")
                .html(`
                    <strong>${city.name}</strong><br>
                    Population: ${formatPopulation(city.pop)}<br>
                    Latitude: ${city.lat}<br>
                    Longitude: ${city.lon}
                `);
        })

        .on("mousemove", function(event) {

            const tooltipWidth = 240;
            const tooltipHeight = 100;

            const left = Math.min(
                event.clientX + 15,
                window.innerWidth - tooltipWidth - 10
            );

            const top = Math.min(
                event.clientY + 15,
                window.innerHeight - tooltipHeight - 10
            );

            tooltip
                .style("left", Math.max(5, left) + "px")
                .style("top", Math.max(5, top) + "px");
        })

        .on("mouseleave", function() {
            tooltip.style("display", "none");
        });

    errorDiv.text("");

    console.log("Pakistan cities map loaded successfully.");
    console.log("Cities plotted:", cities.length);

})
.catch(error => {

    console.error("Map loading error:", error);

    errorDiv.text("Error: " + error.message);
});
