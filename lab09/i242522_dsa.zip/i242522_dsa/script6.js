
(() => {
  "use strict";

  // ==========================================
  // CONFIGURATION
  // ==========================================

  const FILES = {
    cities: "./pakistan_cities.csv",
    flights: "./flights.csv"
  };

  const WIDTH = 1100;
  const HEIGHT = 650;
  const HUB_THRESHOLD = 4;

  const svg = d3.select("#map");
  const status = d3.select("#status");
  const tooltip = d3.select("#tooltip");

  // Clear previous drawings if the script is run again.
  svg.selectAll("*").remove();

  // Routes are deliberately drawn before cities.
  const routeLayer = svg.append("g").attr("class", "routes");
  const cityLayer = svg.append("g").attr("class", "cities");
  const labelLayer = svg.append("g").attr("class", "labels");

  // ==========================================
  // CSV COLUMN HELPERS
  // ==========================================

  function normalizeHeader(value) {
    return String(value ?? "")
      .trim()
      .toLowerCase()
      .replace(/[\s-]+/g, "_");
  }

  function findColumn(rows, candidates, description) {
    if (!rows.length) {
      throw new Error("The CSV file is empty.");
    }

    const headers = Object.keys(rows[0]);
    const normalizedHeaders = headers.map(normalizeHeader);

    for (const candidate of candidates) {
      const index = normalizedHeaders.indexOf(
        normalizeHeader(candidate)
      );

      if (index !== -1) {
        return headers[index];
      }
    }

    throw new Error(
      `Cannot find ${description}. Available columns: ${headers.join(", ")}`
    );
  }

  function toNumber(value) {
    if (value == null) return NaN;

    const cleaned = String(value)
      .trim()
      .replace(/,/g, "")
      .replace(/^\$/, "");

    if (!cleaned) return NaN;

    return Number(cleaned);
  }

  function normalizeCityName(value) {
    return String(value ?? "")
      .normalize("NFKC")
      .trim()
      .toLowerCase()
      .replace(/[_-]+/g, " ")
      .replace(/\s+/g, " ");
  }

  function formatNumber(value) {
    return Number(value).toLocaleString("en-US", {
      maximumFractionDigits: 0
    });
  }

  // ==========================================
  // LOAD AND PREPARE DATA
  // ==========================================

  async function main() {
    try {
      const [cityRows, flightRows] = await Promise.all([
        d3.csv(FILES.cities),
        d3.csv(FILES.flights)
      ]);

      if (!cityRows.length) {
        throw new Error("pakistan_cities.csv contains no data.");
      }

      if (!flightRows.length) {
        throw new Error("flights.csv contains no data.");
      }

      // City CSV column names.
      const cityNameCol = findColumn(
        cityRows,
        ["city", "city_name", "name", "cityname", "location"],
        "city name column"
      );

      const latitudeCol = findColumn(
        cityRows,
        ["latitude", "lat", "city_latitude", "city_lat", "y"],
        "latitude column"
      );

      const longitudeCol = findColumn(
        cityRows,
        ["longitude", "lon", "lng", "long", "city_longitude", "city_lon", "x"],
        "longitude column"
      );

      const populationCol = findColumn(
        cityRows,
        ["population", "pop", "city_population", "total_population"],
        "population column"
      );

      // Flight CSV column names.
      const sourceCol = findColumn(
        flightRows,
        ["source", "origin", "from", "source_city", "sourcecity", "from_city"],
        "flight source column"
      );

      const targetCol = findColumn(
        flightRows,
        ["target", "destination", "dest", "to", "target_city", "targetcity", "to_city"],
        "flight target column"
      );

      const weeklyFlightsCol = findColumn(
        flightRows,
        [
          "flights_per_week",
          "weekly_flights",
          "flights_week",
          "flightsperweek",
          "flights",
          "frequency",
          "weekly_frequency"
        ],
        "weekly flight count column"
      );

      // Convert city values into numbers.
      const cities = cityRows.map((row, index) => {
        const latitude = toNumber(row[latitudeCol]);
        const longitude = toNumber(row[longitudeCol]);
        const population = toNumber(row[populationCol]);
        const name = String(row[cityNameCol] ?? "").trim();

        if (!name) {
          throw new Error(`City name is missing on CSV row ${index + 2}.`);
        }

        if (
          !Number.isFinite(latitude) ||
          latitude < -90 ||
          latitude > 90 ||
          !Number.isFinite(longitude) ||
          longitude < -180 ||
          longitude > 180
        ) {
          throw new Error(
            `Invalid coordinates for "${name}". ` +
            `Check the latitude and longitude columns.`
          );
        }

        if (!Number.isFinite(population) || population < 0) {
          throw new Error(
            `Invalid population for "${name}".`
          );
        }

        return {
          name,
          latitude,
          longitude,
          population,
          routeCount: 0,
          totalWeeklyFlights: 0,
          connectedCities: new Set(),
          isHub: false
        };
      });

      // Match cities by normalized name.
      const cityLookup = new Map();

      for (const city of cities) {
        const key = normalizeCityName(city.name);

        if (cityLookup.has(key)) {
          console.warn(
            `Duplicate normalized city name "${city.name}".`
          );
        }

        cityLookup.set(key, city);
      }

      // Match each flight to its source and target city.
      const flights = [];
      const unmatched = [];

      flightRows.forEach((row, index) => {
        const sourceText = String(row[sourceCol] ?? "").trim();
        const targetText = String(row[targetCol] ?? "").trim();

        const source = cityLookup.get(
          normalizeCityName(sourceText)
        );

        const target = cityLookup.get(
          normalizeCityName(targetText)
        );

        const weeklyFlights = toNumber(row[weeklyFlightsCol]);

        if (!source || !target) {
          unmatched.push({
            row: index + 2,
            source: sourceText,
            target: targetText
          });
          return;
        }

        if (source === target) {
          console.warn(
            `Skipping self-route on flights.csv row ${index + 2}.`
          );
          return;
        }

        if (!Number.isFinite(weeklyFlights) || weeklyFlights < 0) {
          console.warn(
            `Skipping invalid weekly flight count on row ${index + 2}.`
          );
          return;
        }

        flights.push({
          source,
          target,
          flightsPerWeek: weeklyFlights
        });
      });

      if (unmatched.length) {
        console.warn("Unmatched flight routes:", unmatched);
      }

      if (!flights.length) {
        throw new Error(
          "No flight routes could be matched. Check the source/target " +
          "names in flights.csv against the city names in pakistan_cities.csv."
        );
      }

      // ==========================================
      // HUB COUNTS
      // ==========================================

      // Each flight record counts as one route at each endpoint.
      // Flights per week determine line width, not hub status.
      for (const flight of flights) {
        flight.source.routeCount += 1;
        flight.target.routeCount += 1;

        flight.source.totalWeeklyFlights += flight.flightsPerWeek;
        flight.target.totalWeeklyFlights += flight.flightsPerWeek;

        flight.source.connectedCities.add(flight.target.name);
        flight.target.connectedCities.add(flight.source.name);
      }

      for (const city of cities) {
        city.isHub = city.routeCount >= HUB_THRESHOLD;
      }

      // ==========================================
      // GEOGRAPHIC PROJECTION
      // ==========================================

      // Fit the projection to the actual city coordinates.
      // Coordinates must be [longitude, latitude].
      const geoPoints = {
        type: "MultiPoint",
        coordinates: cities.map(city => [
          city.longitude,
          city.latitude
        ])
      };

      const projection = d3.geoEquirectangular()
        .fitExtent(
          [[65, 45], [WIDTH - 65, HEIGHT - 45]],
          geoPoints
        );

      for (const city of cities) {
        const point = projection([
          city.longitude,
          city.latitude
        ]);

        if (!point || !point.every(Number.isFinite)) {
          throw new Error(
            `Could not project coordinates for ${city.name}.`
          );
        }

        city.x = point[0];
        city.y = point[1];
      }

      // ==========================================
      // VISUAL SCALES
      // ==========================================

      const populationMax = d3.max(
        cities,
        city => city.population
      ) || 1;

      // Circle AREA is proportional to population.
      const radius = d3.scaleSqrt()
        .domain([0, populationMax])
        .range([3, 18]);

      const maxWeeklyFlights = d3.max(
        flights,
        flight => flight.flightsPerWeek
      ) || 1;

      const lineWidth = d3.scaleLinear()
        .domain([0, maxWeeklyFlights])
        .range([0.8, 6])
        .clamp(true);

      function cityFill(city) {
        return city.isHub ? "#dc2626" : "#2563eb";
      }

      // ==========================================
      // DRAW ROUTES FIRST
      // ==========================================

      const routeSelection = routeLayer
        .selectAll("line")
        .data(flights)
        .join("line")
        .attr("class", "route")
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y)
        .attr("stroke-width", d =>
          lineWidth(d.flightsPerWeek)
        )
        .attr("data-source", d => d.source.name)
        .attr("data-target", d => d.target.name);

      // ==========================================
      // DRAW CITIES ON TOP
      // ==========================================

      const citySelection = cityLayer
        .selectAll("circle")
        .data(cities)
        .join("circle")
        .attr("class", "city")
        .attr("cx", d => d.x)
        .attr("cy", d => d.y)
        .attr("r", d => radius(d.population))
        .attr("fill", cityFill)
        .attr("data-city", d => d.name)
        .on("mouseenter", function(event, city) {
          highlightCity(city);

          tooltip
            .style("display", "block")
            .html(`
              <strong>${escapeHTML(city.name)}</strong><br>
              Population: ${formatNumber(city.population)}<br>
              Type: ${city.isHub ? "Hub city" : "Non-hub city"}<br>
              Routes: ${city.routeCount}<br>
              Connected cities: ${city.connectedCities.size}<br>
              Weekly flights on incident routes:
              ${formatNumber(city.totalWeeklyFlights)}
            `);

          moveTooltip(event);
        })
        .on("mousemove", function(event) {
          moveTooltip(event);
        })
        .on("mouseleave", function() {
          resetHighlight();
          tooltip.style("display", "none");
        });

      // ==========================================
      // CITY LABELS
      // ==========================================

      labelLayer
        .selectAll("text")
        .data(cities)
        .join("text")
        .attr("class", "city-label")
        .attr("x", d => d.x + radius(d.population) + 4)
        .attr("y", d => d.y - radius(d.population) - 2)
        .text(d => d.name);

      // ==========================================
      // HOVER INTERACTION
      // ==========================================

      function highlightCity(city) {
        routeSelection
          .classed("highlighted", d =>
            d.source === city || d.target === city
          )
          .classed("dimmed", d =>
            d.source !== city && d.target !== city
          );

        citySelection
          .classed("highlighted", d => d === city)
          .classed("dimmed", d =>
            d !== city &&
            !d.connectedCities.has(city.name)
          );

        labelLayer
          .selectAll("text")
          .attr("opacity", d =>
            d === city || d.connectedCities.has(city.name)
              ? 1
              : 0.2
          );
      }

      function resetHighlight() {
        routeSelection
          .classed("highlighted", false)
          .classed("dimmed", false);

        citySelection
          .classed("highlighted", false)
          .classed("dimmed", false);

        labelLayer
          .selectAll("text")
          .attr("opacity", 1);
      }

      function moveTooltip(event) {
        const tooltipNode = tooltip.node();
        const padding = 12;

        let left = event.clientX + padding;
        let top = event.clientY + padding;

        if (left + tooltipNode.offsetWidth > window.innerWidth - 8) {
          left = event.clientX - tooltipNode.offsetWidth - padding;
        }

        if (top + tooltipNode.offsetHeight > window.innerHeight - 8) {
          top = event.clientY - tooltipNode.offsetHeight - padding;
        }

        tooltip
          .style("left", `${Math.max(4, left)}px`)
          .style("top", `${Math.max(4, top)}px`);
      }

      function escapeHTML(value) {
        return String(value).replace(/[&<>"']/g, char => ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;"
        })[char]);
      }

      // ==========================================
      // DYNAMIC LEGEND
      // ==========================================

      const legend = d3.select("#legend");

      function addLegendItem(className, label, width) {
        const item = legend
          .append("div")
          .attr("class", "legend-item");

        item.append("span")
          .attr("class", className)
          .style("width", width ? `${width}px` : null);

        item.append("span").text(label);
      }

      addLegendItem(
        "dot size-small",
        `Population: ${formatNumber(d3.min(cities, d => d.population))}`
      );

      addLegendItem(
        "dot size-large",
        `Population: ${formatNumber(populationMax)}`
      );

      addLegendItem(
        "line-small",
        `Weekly flights: 0`,
        40
      );

      addLegendItem(
        "line-large",
        `Weekly flights: ${formatNumber(maxWeeklyFlights)}`,
        40
      );

      // ==========================================
      // STATUS AND DIAGNOSTICS
      // ==========================================

      const hubCount = cities.filter(city => city.isHub).length;

      status.text(
        `Loaded ${cities.length} cities and ${flights.length} matched routes. ` +
        `Hub cities: ${hubCount}. ` +
        `Unmatched flight rows: ${unmatched.length}. ` +
        `Hover over a city to explore its routes.`
      );

      console.log("City data:", cities);
      console.log("Matched flight data:", flights);
      console.log("Unmatched routes:", unmatched);

    } catch (error) {
      console.error("Task 6 error:", error);

      status
        .style("color", "#dc2626")
        .text(`Error: ${error.message}`);
    }
  }

  main();
})();
