// Lab Manual 10 - Air Quality Time Series Dashboard
// Keep index.html, lab10.js and air_quality_2025.csv in the same folder.

const file = "air_quality_2025.csv";
const margin = {top: 25, right: 25, bottom: 45, left: 58};
const width = 850, height = 330;
const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const weekdays = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
const colors = {city:"#2563eb", suburb:"#f97316", low:"#dbeafe", moderate:"#93c5fd", high:"#3b82f6", severe:"#1e3a8a"};

d3.csv(file, d => ({
  date: d3.timeParse("%Y-%m-%d")(d.date),
  pm25_city: +d.pm25_city,
  pm25_suburb: +d.pm25_suburb,
  temp_c: +d.temp_c
})).then(data => {
  data = data.filter(d => d.date && Number.isFinite(d.pm25_city)).sort((a,b) => a.date-b.date);
  if (!data.length) throw new Error("No valid rows found in CSV.");

  const fmt = d3.timeFormat("%d %b %Y");
  const monthFmt = d3.timeFormat("%b");
  const first = data[0].date, last = data[data.length-1].date;
  const expectedDays = d3.timeDay.count(first, d3.timeDay.offset(last,1));
  const missingDays = expectedDays - data.length;
  const above15 = data.filter(d => d.pm25_city > 15).length;
  const above75 = data.filter(d => d.pm25_city > 75).length;
  const topTwo = [...data].sort((a,b) => b.pm25_city-a.pm25_city).slice(0,2);
  const gapPairs = [];
  for (let i=1;i<data.length;i++) {
    const diff = d3.timeDay.count(data[i-1].date,data[i].date);
    if (diff > 1) gapPairs.push({start:d3.timeDay.offset(data[i-1].date,1), end:data[i].date, days:diff-1});
  }

  d3.select("#summary").html(`
    <div class="metric"><small>Recorded days</small><strong>${data.length}</strong></div>
    <div class="metric"><small>Missing days</small><strong>${missingDays}</strong></div>
    <div class="metric"><small>Days above 15 µg/m³</small><strong>${above15}</strong></div>
    <div class="metric"><small>Days above 75 µg/m³</small><strong>${above75}</strong></div>
    <div class="metric"><small>Highest city reading</small><strong>${topTwo[0].pm25_city.toFixed(1)}</strong></div>
  `);
  d3.select("#dataNote").text(
    `Dataset check: ${data.length} rows, from ${fmt(first)} to ${fmt(last)}. ` +
    `There are ${missingDays} missing calendar days. ${gapPairs.map(g => `${g.days} missing days between ${fmt(d3.timeDay.offset(g.start,-1))} and ${fmt(g.end)}`).join("; ")}.`
  );

  const xTime = d3.scaleTime().domain([first,last]).range([margin.left,width-margin.right]);
  const maxCity = d3.max(data,d=>d.pm25_city);
  const y = d3.scaleLinear().domain([0,Math.ceil(maxCity/50)*50]).nice().range([height-margin.bottom,margin.top]);

  // Task 2: daily line with WHO reference lines and two maximum observations.
  {
    const svg = makeSvg("#chart1");
    addAxes(svg,xTime,y);
    [15,75].forEach((v,i)=>{
      svg.append("line").attr("x1",margin.left).attr("x2",width-margin.right)
        .attr("y1",y(v)).attr("y2",y(v)).attr("stroke",i?"#dc2626":"#16a34a")
        .attr("stroke-dasharray","7,5").attr("stroke-width",1.5);
      svg.append("text").attr("x",width-margin.right-4).attr("y",y(v)-5)
        .attr("text-anchor","end").attr("fill",i?"#dc2626":"#16a34a").attr("font-size",11)
        .text(`${v} µg/m³`);
    });
    svg.append("path").datum(data).attr("fill","none").attr("stroke",colors.city).attr("stroke-width",1.8)
      .attr("d",d3.line().defined(d=>d.pm25_city!=null).x(d=>xTime(d.date)).y(d=>y(d.pm25_city)));
    topTwo.forEach((d,i)=>{
      svg.append("circle").attr("cx",xTime(d.date)).attr("cy",y(d.pm25_city)).attr("r",5).attr("fill","#dc2626");
      svg.append("text").attr("x",xTime(d.date)+(i===0?-8:8)).attr("y",y(d.pm25_city)-10)
        .attr("text-anchor",i===0?"end":"start").attr("font-size",11).attr("font-weight","bold")
        .attr("fill","#991b1b").text(`${fmt(d.date)}: ${d.pm25_city}`);
    });
    svg.append("text").attr("x",margin.left).attr("y",16).attr("font-size",12).attr("fill","#334155")
      .text(`Above 15: ${above15} days (${(100*above15/data.length).toFixed(1)}%)  |  Above 75: ${above75} days (${(100*above75/data.length).toFixed(1)}%)`);
  }

  // Task 3: running total of unhealthy days.
  {
    let running=0;
    const cumulative=data.map(d=>({...d, running: running += (d.pm25_city>75 ? 1:0)}));
    const svg=makeSvg("#chart2");
    const yy=d3.scaleLinear().domain([0,above75]).nice().range([height-margin.bottom,margin.top]);
    addAxes(svg,xTime,yy);
    svg.append("path").datum(cumulative).attr("fill","#93c5fd").attr("opacity",0.65)
      .attr("d",d3.area().x(d=>xTime(d.date)).y0(yy(0)).y1(d=>yy(d.running)));
    svg.append("path").datum(cumulative).attr("fill","none").attr("stroke","#1d4ed8").attr("stroke-width",2)
      .attr("d",d3.line().x(d=>xTime(d.date)).y(d=>yy(d.running)));
    svg.append("text").attr("x",width-margin.right).attr("y",yy(above75)-8).attr("text-anchor","end")
      .attr("font-weight","bold").text(`Final total: ${above75}`);
  }

  // Task 4: two daily series.
  {
    const svg=makeSvg("#chart3");
    const ymax=d3.max(data,d=>Math.max(d.pm25_city,d.pm25_suburb));
    const yy=d3.scaleLinear().domain([0,Math.ceil(ymax/50)*50]).nice().range([height-margin.bottom,margin.top]);
    addAxes(svg,xTime,yy);
    [["pm25_city",colors.city,"City centre"],["pm25_suburb",colors.suburb,"Suburb"]].forEach(([key,color,label])=>{
      svg.append("path").datum(data).attr("fill","none").attr("stroke",color).attr("stroke-width",1.7)
        .attr("d",d3.line().x(d=>xTime(d.date)).y(d=>yy(d[key])));
    });
    legend(svg,[["City centre",colors.city],["Suburb",colors.suburb]],margin.left,18);
  }

  // Task 5: monthly stacked counts by pollution level.
  const levels=["Low","Moderate","High","Severe"];
  const monthlyCounts=months.map((m,i)=>{
    const rows=data.filter(d=>d.date.getMonth()===i);
    const result={month:m, days:rows.length};
    rows.forEach(d=>{
      const v=d.pm25_city;
      const level=v<=35?"Low":v<=75?"Moderate":v<=150?"High":"Severe";
      result[level]=(result[level]||0)+1;
    });
    levels.forEach(k=>result[k] ||= 0);
    return result;
  });
  {
    const svg=makeSvg("#chart4");
    const innerW=width-margin.left-margin.right, innerH=height-margin.top-margin.bottom;
    const xx=d3.scaleBand().domain(months).range([margin.left,width-margin.right]).padding(0.12);
    const maxDays=d3.max(monthlyCounts,d=>d3.sum(levels,k=>d[k]));
    const yy=d3.scaleLinear().domain([0,maxDays]).nice().range([height-margin.bottom,margin.top]);
    const stack=d3.stack().keys(levels)(monthlyCounts);
    const levelColors=["#dbeafe","#93c5fd","#3b82f6","#1e3a8a"];
    svg.append("g").selectAll("g").data(stack).join("g").attr("fill",(d,i)=>levelColors[i])
      .selectAll("rect").data(d=>d).join("rect")
      .attr("x",d=>xx(d.data.month)).attr("y",d=>yy(d[1]))
      .attr("height",d=>Math.max(0,yy(d[0])-yy(d[1]))).attr("width",xx.bandwidth());
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${height-margin.bottom})`).call(d3.axisBottom(xx));
    svg.append("g").attr("class","axis").attr("transform",`translate(${margin.left},0)`).call(d3.axisLeft(yy).ticks(5));
    legend(svg,levels.map((k,i)=>[k,levelColors[i]]),margin.left,17);
  }

  // Task 6: month x weekday heatmap.
  {
    const cells=[];
    months.forEach((m,mi)=>weekdays.forEach((w,wi)=>{
      const vals=data.filter(d=>d.date.getMonth()===mi && (d.date.getDay()+6)%7===wi).map(d=>d.pm25_city);
      cells.push({month:m,weekday:w,avg:vals.length?d3.mean(vals):null,count:vals.length});
    }));
    const svg=makeSvg("#chart5");
    const xx=d3.scaleBand().domain(weekdays).range([margin.left,width-margin.right]).padding(0.06);
    const yy=d3.scaleBand().domain(months).range([margin.top+12,height-margin.bottom]).padding(0.06);
    const color=d3.scaleSequential(d3.interpolateYlOrRd).domain([0,d3.max(cells,d=>d.avg)]);
    svg.selectAll("rect").data(cells).join("rect")
      .attr("x",d=>xx(d.weekday)).attr("y",d=>yy(d.month)).attr("width",xx.bandwidth()).attr("height",yy.bandwidth())
      .attr("fill",d=>d.avg==null?"#e5e7eb":color(d.avg))
      .append("title").text(d=>`${d.month} ${d.weekday}: ${d.avg==null?"No data":d.avg.toFixed(1)+" µg/m³"} (${d.count} days)`);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${height-margin.bottom})`).call(d3.axisBottom(xx));
    svg.append("g").attr("class","axis").attr("transform",`translate(${margin.left},0)`).call(d3.axisLeft(yy));
    const defs=svg.append("defs"), grad=defs.append("linearGradient").attr("id","heatGrad");
    grad.append("stop").attr("offset","0%").attr("stop-color",color(0));
    grad.append("stop").attr("offset","100%").attr("stop-color",color(d3.max(cells,d=>d.avg)));
    svg.append("rect").attr("x",width-210).attr("y",7).attr("width",150).attr("height",9).attr("fill","url(#heatGrad)");
    svg.append("text").attr("x",width-210).attr("y",29).attr("font-size",10).text("Lower average");
    svg.append("text").attr("x",width-60).attr("y",29).attr("font-size",10).attr("text-anchor","end").text("Higher");
  }

  // Task 7: monthly min-max band and mean line.
  const monthlyStats=months.map((m,i)=>{
    const vals=data.filter(d=>d.date.getMonth()===i).map(d=>d.pm25_city);
    return {month:m,min:d3.min(vals),max:d3.max(vals),mean:d3.mean(vals),range:d3.max(vals)-d3.min(vals)};
  });
  {
    const svg=makeSvg("#chart6");
    const xx=d3.scalePoint().domain(months).range([margin.left,width-margin.right]).padding(0.3);
    const yy=d3.scaleLinear().domain([0,d3.max(monthlyStats,d=>d.max)]).nice().range([height-margin.bottom,margin.top]);
    svg.append("g").attr("class","axis").attr("transform",`translate(0,${height-margin.bottom})`).call(d3.axisBottom(xx));
    svg.append("g").attr("class","axis").attr("transform",`translate(${margin.left},0)`).call(d3.axisLeft(yy).ticks(6));
    svg.append("path").datum(monthlyStats).attr("fill","#bfdbfe").attr("opacity",0.8)
      .attr("d",d3.area().x(d=>xx(d.month)).y0(d=>yy(d.min)).y1(d=>yy(d.max)));
    svg.append("path").datum(monthlyStats).attr("fill","none").attr("stroke","#ea580c").attr("stroke-width",3)
      .attr("d",d3.line().x(d=>xx(d.month)).y(d=>yy(d.mean)));
    svg.selectAll("circle").data(monthlyStats).join("circle").attr("cx",d=>xx(d.month)).attr("cy",d=>yy(d.mean)).attr("r",3.5).attr("fill","#ea580c");
    legend(svg,[["Min–max range","#93c5fd"],["Monthly mean","#ea580c"]],margin.left,17);
  }

  // Task 8: seven-day moving average; split into separate paths across missing dates.
  {
    const segments=[];
    let segment=[];
    for(let i=0;i<data.length;i++){
      if(i>0 && d3.timeDay.count(data[i-1].date,data[i].date)>1){ if(segment.length)segments.push(segment); segment=[]; }
      segment.push(data[i]);
    }
    if(segment.length)segments.push(segment);
    segments.forEach(seg=>{
      seg.forEach((d,i)=>{
        d.moving = i>=6 ? d3.mean(seg.slice(i-6,i+1),x=>x.pm25_city) : null;
      });
    });
    const svg=makeSvg("#chart7");
    addAxes(svg,xTime,y);
    gapPairs.forEach(g=>{
      svg.append("rect").attr("x",xTime(g.start)).attr("y",margin.top).attr("width",Math.max(8,xTime(g.end)-xTime(g.start)))
        .attr("height",height-margin.top-margin.bottom).attr("fill","#fbbf24").attr("opacity",0.25);
      svg.append("text").attr("x",(xTime(g.start)+xTime(g.end))/2).attr("y",margin.top+15)
        .attr("text-anchor","middle").attr("font-size",11).attr("fill","#92400e").text("No data: sensor offline");
    });
    segments.forEach(seg=>{
      svg.append("path").datum(seg).attr("fill","none").attr("stroke","#94a3b8").attr("stroke-width",1).attr("opacity",0.55)
        .attr("d",d3.line().x(d=>xTime(d.date)).y(d=>y(d.pm25_city)));
      svg.append("path").datum(seg.filter(d=>d.moving!=null)).attr("fill","none").attr("stroke","#0f172a").attr("stroke-width",3)
        .attr("d",d3.line().x(d=>xTime(d.date)).y(d=>y(d.moving)));
    });
    legend(svg,[["Daily PM2.5","#94a3b8"],["7-day average","#0f172a"]],margin.left,17);
    svg.append("text").attr("x",width-margin.right).attr("y",height-8).attr("text-anchor","end").attr("font-size",11)
      .text(`Missing days: ${missingDays}`);
  }

  // Task 9: focus chart with brushable year overview.
  {
    const svg=makeSvg("#chart8",height+80);
    const mainTop=margin.top, mainBottom=height-margin.bottom;
    const xOverview=d3.scaleTime().domain([first,last]).range([margin.left,width-margin.right]);
    const xFocus=d3.scaleTime().domain([first,last]).range([margin.left,width-margin.right]);
    const mainY=d3.scaleLinear().domain([0,Math.ceil(maxCity/50)*50]).nice().range([mainBottom,mainTop]);
    const mainGroup=svg.append("g");
    mainGroup.append("g").attr("class","axis").attr("transform",`translate(0,${mainBottom})`).call(d3.axisBottom(xFocus).ticks(8));
    mainGroup.append("g").attr("class","axis").attr("transform",`translate(${margin.left},0)`).call(d3.axisLeft(mainY).ticks(5));
    const focusSegments=[];
    let focusSegment=[];
    data.forEach((d,i)=>{
      if(i>0 && d3.timeDay.count(data[i-1].date,d.date)>1){focusSegments.push(focusSegment);focusSegment=[];}
      focusSegment.push(d);
    });
    if(focusSegment.length)focusSegments.push(focusSegment);
    const focusLine=d3.line().x(d=>xFocus(d.date)).y(d=>mainY(d.pm25_city));
    const focusPaths=focusSegments.map(seg=>mainGroup.append("path").datum(seg).attr("fill","none")
      .attr("stroke",colors.city).attr("stroke-width",2));
    const overviewY=d3.scaleLinear().domain(mainY.domain()).range([height+42,height+8]);
    const overviewLine=d3.line().x(d=>xOverview(d.date)).y(d=>overviewY(d.pm25_city));
    svg.append("path").datum(data).attr("fill","none").attr("stroke","#64748b").attr("stroke-width",1.2).attr("d",overviewLine);
    const brush=d3.brushX().extent([[margin.left,height+4],[width-margin.right,height+47]])
      .on("brush end",({selection})=>{
        if(!selection)return;
        const domain=selection.map(xOverview.invert);
        xFocus.domain(domain);
        mainGroup.select(".axis").call(d3.axisBottom(xFocus).ticks(8));
        focusPaths.forEach((path,i)=>path.attr("d",focusLine(focusSegments[i])));
      });
    const brushG=svg.append("g").attr("class","brush").call(brush);
    brushG.call(brush.move,[xOverview(first),xOverview(last)]);
    d3.select("#resetZoom").on("click",()=>brushG.call(brush.move,[xOverview(first),xOverview(last)]));
    svg.append("text").attr("x",margin.left).attr("y",height+68).attr("font-size",11).text("Full-year overview — drag a selection to zoom");
  }

  // Director's answers from the supplied practice dataset.
  const byMonth=monthlyStats.slice().sort((a,b)=>b.mean-a.mean);
  const best=monthlyStats.reduce((a,b)=>a.mean<b.mean?a:b);
  const worst=monthlyStats.reduce((a,b)=>a.mean>b.mean?a:b);
  const widest=monthlyStats.reduce((a,b)=>a.range>b.range?a:b);
  const severeMonths=monthlyCounts.filter(d=>d.Severe>0).map(d=>d.month);
  const mostLow=monthlyCounts.reduce((a,b)=>a.Low>b.Low?a:b);
  const dayMeans=weekdays.map(w=>{
    const vals=data.filter(d=>["Mon","Tue","Wed","Thu","Fri","Sat","Sun"][(d.date.getDay()+6)%7]===w).map(d=>d.pm25_city);
    return {day:w,mean:d3.mean(vals)};
  });
  const dayRange=d3.max(dayMeans,d=>d.mean)-d3.min(dayMeans,d=>d.mean);
  const monthMeans=monthlyStats.map(d=>d.mean);
  const corr=d3.mean(data,d=>d.pm25_city); // overall city mean for context
  const suburbMonth=months.map((m,i)=>({
    month:m,
    city:d3.mean(data.filter(d=>d.date.getMonth()===i),d=>d.pm25_city),
    suburb:d3.mean(data.filter(d=>d.date.getMonth()===i),d=>d.pm25_suburb)
  }));
  const maxDiff=suburbMonth.reduce((a,b)=>Math.abs(a.city-a.suburb)>Math.abs(b.city-b.suburb)?a:b);
  const answerHTML = `
    <h3>Seasonality</h3><p>The highest monthly mean is ${worst.month} (${worst.mean.toFixed(1)} µg/m³), while the lowest is ${best.month} (${best.mean.toFixed(1)} µg/m³). The worst-month average is about ${(worst.mean/best.mean).toFixed(1)} times the best-month average.</p>
    <h3>Anomalies</h3><p>The two highest city readings are ${fmt(topTwo[0].date)} (${topTwo[0].pm25_city.toFixed(1)} µg/m³) and ${fmt(topTwo[1].date)} (${topTwo[1].pm25_city.toFixed(1)} µg/m³). The ${monthFmt(topTwo[0].date)} peak occurs in a generally polluted part of the year, while the ${monthFmt(topTwo[1].date)} peak is a sharp spike compared with that month's average. Possible real-world causes could include weather conditions, dust, traffic, industrial emissions or biomass burning; this dataset alone cannot identify the cause.</p>
    <h3>Guideline</h3><p>${above15} of ${data.length} recorded days (${(100*above15/data.length).toFixed(1)}%) were above 15 µg/m³, and ${above75} days (${(100*above75/data.length).toFixed(1)}%) were above 75 µg/m³.</p>
    <h3>Build-up</h3><p>The cumulative unhealthy-day count rises fastest during months with many readings above 75, especially January, February, March and November–December. It becomes much flatter in June, July and August when city readings are lower.</p>
    <h3>Comparison</h3><p>The city and suburb series follow a broadly similar seasonal pattern, with higher pollution around the colder months and lower readings in summer. The largest absolute difference between their monthly means is in ${maxDiff.month} (city ${maxDiff.city.toFixed(1)}, suburb ${maxDiff.suburb.toFixed(1)} µg/m³). The suburb is not identical to the city, so station-level differences remain important.</p>
    <h3>Composition</h3><p>Severe days occur in ${severeMonths.join(", ")}. ${mostLow.month} has the most Low days (${mostLow.Low}). Months have different lengths because calendar months contain 28, 30 or 31 days; additionally, missing readings reduce the recorded-day totals in March.</p>
    <h3>Pattern</h3><p>Weekday averages are relatively close (range ${dayRange.toFixed(1)} µg/m³ across weekday means), while monthly averages vary much more. This suggests the dominant pattern is seasonal/monthly rather than a strong day-of-week effect. It may reflect weather and seasonal emission conditions, but the dataset cannot prove a cause.</p>
    <h3>Spread</h3><p>${widest.month} has the widest monthly range: ${(widest.max-widest.min).toFixed(1)} µg/m³ (minimum ${widest.min.toFixed(1)}, maximum ${widest.max.toFixed(1)}). A monthly mean hides the extremes and the day-to-day variability.</p>
    <h3>Trend and data quality</h3><p>The data shows a seasonal cycle: high values near the beginning and end of the year and lower values in summer. There are ${missingDays} missing days. An unbroken line across the gap would imply measurements existed when the sensor was offline.</p>
    <h3>Zoom</h3><p>${widest.month} has the widest spread. Use the interactive overview above to select that month and inspect its daily spikes and variation.</p>
    <h3>Chart choice</h3><p>A pie chart cannot show when pollution rose or fell, and it cannot reveal daily spikes, missing dates, or the progression of unhealthy days. The time-series charts show these changes and gaps.</p>
    <h3>Recommendation</h3><p>If restrictions can cover only two months, choose ${worst.month} and ${monthlyStats.slice().sort((a,b)=>b.mean-a.mean)[1].month}: they have the two highest monthly averages. The monthly spread chart and the daily line chart also show high readings and severe episodes during these periods. This is a data-based recommendation from the practice dataset, not an official air-quality assessment.</p>
  `;
  d3.select("#directorAnswers").html(answerHTML);

}).catch(error => {
  console.error(error);
  d3.select("#dataNote").text("Could not load the CSV. Keep air_quality_2025.csv in the same folder and open the page using VS Code Live Server.");
});

function makeSvg(selector, h=height) {
  return d3.select(selector).append("svg").attr("viewBox",`0 0 ${width} ${h}`).attr("role","img");
}
function addAxes(svg,x,y) {
  svg.append("g").attr("class","axis").attr("transform",`translate(0,${height-margin.bottom})`)
    .call(d3.axisBottom(x).ticks(8));
  svg.append("g").attr("class","axis").attr("transform",`translate(${margin.left},0)`).call(d3.axisLeft(y).ticks(6));
  svg.append("text").attr("x",width/2).attr("y",height-5).attr("text-anchor","middle").attr("font-size",11).attr("fill","#475569").text("Date");
  svg.append("text").attr("transform","rotate(-90)").attr("x",-height/2).attr("y",16)
    .attr("text-anchor","middle").attr("font-size",11).attr("fill","#475569").text("PM2.5 (µg/m³)");
}
function legend(svg,items,x,y) {
  const g=svg.append("g").attr("class","legend").attr("transform",`translate(${x},${y})`);
  let offset=0;
  items.forEach(([label,color])=>{
    g.append("rect").attr("x",offset).attr("y",-9).attr("width",10).attr("height",10).attr("fill",color);
    g.append("text").attr("x",offset+15).attr("y",0).text(label);
    offset+=label.length*7+35;
  });
}
